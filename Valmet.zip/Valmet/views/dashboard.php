<?php
// Passo 1: Incluir o autoloader do Composer para carregar a biblioteca
require '../vendor/autoload.php';

// Importar a classe necessária da PhpSpreadsheet
use PhpOffice\PhpSpreadsheet\IOFactory;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;

// Passo 2: Definir o caminho para o seu arquivo Excel
// ATENÇÃO: Altere este caminho para o local correto do seu arquivo!
$excelFilePath = '../utils/dados_producao.xlsx';
$tableRows = []; // Inicializa a variável para evitar erros

try {
    // Carregar o arquivo da planilha
    $spreadsheet = IOFactory::load($excelFilePath);
    
    // Pegar a primeira planilha (aba) do arquivo
    $sheet = $spreadsheet->getActiveSheet();
    
    // Converter a planilha em um array PHP
    // O 'true, true, true, true' garante que pegamos os valores formatados
    $data = $sheet->toArray(null, true, true, true);
    
} catch (Exception $e) {
    // Se houver um erro (ex: arquivo não encontrado), exibe uma mensagem
    echo 'Erro ao carregar o arquivo: ' . $e->getMessage();
    die();
}

// --- NOVA LÓGICA DOS CONTADORES ---

// 1. Inicializar os contadores
$contadores = [
    'espera' => 0,
    'andamento' => 0,
    'revisao' => 0,
    'concluido' => 0,
    'alerta' => 0,
];

// 2. Mapear as colunas da planilha para facilitar a leitura do código
// (Baseado no seu exemplo: A=0, B=1, C=2, etc.)
$colunas = [
    'dataEntrega' => 'F',
    'dataReprog' => 'G',
    'engInd' => 'I',
    'suprimentos' => 'J',
    'cqReceb' => 'K',
    'corteSerra' => 'L',
];

// Pega a data de hoje para comparar
$hoje = new DateTime();

// 3. Processar cada linha de dados (pulando o cabeçalho)
if (count($data) > 2) {
    foreach (array_slice($data, 2) as $row) {
        // Pega o status da última etapa para verificações de "concluído"
        $statusFinal = $row[$colunas['corteSerra']] ?? '';
        $isConcluido = (stripos($statusFinal, 'Concluído') !== false);

        // --- Lógica de verificação, em ordem de prioridade ---

        // REGRA DE ALERTA: Data passou e não está concluído
        $dataEntregaStr = !empty($row[$colunas['dataReprog']]) ? $row[$colunas['dataReprog']] : $row[$colunas['dataEntrega']];
        
        try {
            $dataEntrega = new DateTime($dataEntregaStr);
            if ($dataEntrega < $hoje && !$isConcluido) {
                $contadores['alerta']++;
                continue; // Pula para a próxima linha para não contar duas vezes
            }
        } catch (Exception $ex) {
            // Ignora datas inválidas
        }

        // REGRA DE CONCLUÍDO
        if ($isConcluido) {
            $contadores['concluido']++;
            continue;
        }

        // REGRA DE REVISÃO
        $statusConcatenado = implode(' ', [
            $row[$colunas['engInd']], 
            $row[$colunas['suprimentos']], 
            $row[$colunas['cqReceb']], 
            $row[$colunas['corteSerra']]
        ]);

        if (stripos($statusConcatenado, 'Revisão') !== false || stripos($statusConcatenado, 'Pendente') !== false) {
            $contadores['revisao']++;
            continue;
        }

        // REGRA DE EM ANDAMENTO
        if (stripos($statusConcatenado, 'Em andamento') !== false) {
            $contadores['andamento']++;
            continue;
        }

        // REGRA DE EM ESPERA
        if (stripos($statusConcatenado, 'Em espera') !== false || stripos($statusConcatenado, 'Aguardando') !== false) {
            $contadores['espera']++;
            continue;
        }
    }
}

// --- FIM DA LÓGICA DOS CONTADORES ---
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>DAY@SHOP PRODUCTION-WORKSHOP</title>
  <link rel="stylesheet" href="../CSS/dashboard.css">
  <style>
    body {
      font-family: Arial, sans-serif;
      margin: 0;
      background: #f4f4f4;
    }

    header {
      display: flex;
      align-items: center;
      justify-content: space-between;
      background-color: #0bc650;
      color: white;
      padding: 10px 20px;
    }

    .menu-icon {
      font-size: 24px;
      cursor: pointer;
    }

    .logo {
      background: white;
      color: #0bc650;
      border-radius: 20px;
      padding: 4px 10px;
      font-weight: bold;
      display: flex;
      align-items: center;
      gap: 5px;
    }

    .logo::after {
      content: ">";
      font-size: 18px;
    }

    .title {
      font-weight: bold;
      font-size: 18px;
    }

    .week-input {
      background: white;
      padding: 5px 10px;
      border-radius: 10px;
      border: none;
    }

    .counters {
      display: flex;
      justify-content: space-around;
      flex-wrap: wrap;
      margin: 10px 0;
    }

    .counter {
      flex: 1;
      margin: 10px;
      padding: 15px;
      border-radius: 10px;
      color: black;
      text-align: center;
      font-size: 20px;
      box-shadow: 2px 2px 6px rgba(0,0,0,0.1);
      min-width: 120px;
    }

    .counter span {
      display: block;
      font-size: 32px;
      font-weight: bold;
    }

    .em-espera { background: #5ee9ff; }
    .em-andamento { background: #fff87c; }
    .revisao { background: #ffaf5e; }
    .concluido { background: #7cff80; }
    .em-alerta { background: #ff5e5e; }

    /* Adicione este estilo para indicar que as células são editáveis */
    tbody td {
        cursor: pointer;
        transition: background-color 0.2s;
    }

    tbody td:hover {
        background-color: #f5f5f5; /* Um leve destaque ao passar o mouse */
    }

    table {
      width: 100%;
      border-collapse: collapse;
      white-space: nowrap;
      margin: 0 auto;
      font-size: 14px;
      table-layout: fixed;
    }

    tbody {
      color: black;
    }
    th, td {
      border: 1px solid #ddd;
      padding: 6px;
      text-align: center;
      background: white;
    }

    th {
      border: none;
      top: 0;
      position: sticky;
      background-color: #000;
      color: white;
      font-weight: normal;
      padding: 8px 10px;
      text-align: center;
    }

    td {
      height: 30px;
    }

  /* Larguras específicas das colunas para melhor layout */
  .col-fixed {width: 50px;text-align: left;}
  .col-item {width: 250px;text-align: left;}
  .col-cliente { width: 150px; text-align: left; }
  .col-obs { width: 300px; text-align: left; white-space: normal; }
  .col-day { width: 30px; }
  .col-status { width: 40px; }
  </style>
</head>
<body>

  <header>
    <button id="home-icon"><a id="viewHome" href="logout.php"></a></button>
    <div class="title">DAY@SHOP PRODUCTION-WORKSHOP</div>
    <input class="week-input" type="text" placeholder="SEMANA:" />
  </header>

  <?php include 'components/dashboard/toolBar.php'; ?>

  <section class="counters">
    <div class="counter em-espera">Em espera <span id="espera"><?php echo $contadores['espera']; ?></span></div>
    <div class="counter em-andamento">Em andamento <span id="andamento"><?php echo $contadores['andamento']; ?></span></div>
    <div class="counter revisao">Revisão <span id="revisao"><?php echo $contadores['revisao']; ?></span></div>
    <div class="counter concluido">Concluído <span id="concluido"><?php echo $contadores['concluido']; ?></span></div>
    <div class="counter em-alerta">Em alerta <span id="alerta"><?php echo $contadores['alerta']; ?></span></div>
  </section>
  <main>
    <div class="gantt-container">
      <table>
        <thead>
          <tr>
            <th class="col-fixed">PRI</th>
            <th class="col-fixed">BU</th>
            <th class="col-fixed">PCS</th>
            <th class="col-cliente">Cliente</th>
            <th class="col-item">Item</th>
            <th class="col-cliente">DataEntrega</th>
            <th class="col-cliente">DataReprog</th>
            <th class="col-cliente">Custos</th>
            <th class="col-cliente">Eng Ind</th>
            <th class="col-cliente">Suprimentos</th>
            <th class="col-cliente">CQ Recebimento</th>
            <th class="col-cliente">Corte/Serra</th>
            <th class="col-cliente">Usinagem</th>
            <th class="col-cliente">Solda</th>
            <th class="col-cliente">Caldeiraria</th>
            <th class="col-obs">Observações</th>
          </tr>
        </thead>
        <tbody>
          <?php
            // Passo 3: Iterar sobre os dados e criar as linhas da tabela
            if (!empty($data)) {
                // Começa um loop, pulando a primeira linha (cabeçalho do Excel)
                foreach (array_slice($data, 2) as $row) {
                    echo "<tr>";
                    
                    // --- CÓDIGO CORRIGIDO ---
                    // Pega apenas as 16 primeiras colunas da linha, ignorando o resto.
                    $colunas_a_exibir = array_slice($row, 0, 26); 

                    foreach ($colunas_a_exibir as $cell) {
                        // Usar '?? ""' é uma segurança extra para o caso de uma célula ser nula.
                        echo "<td>" . htmlspecialchars($cell ?? '') . "</td>";
                    }
                    // --- FIM DA CORREÇÃO ---

                    echo "</tr>";
                }
            } else {
                // Mensagem caso a planilha esteja vazia ou não tenha sido carregada
                echo '<tr><td colspan="16">Nenhum dado encontrado na planilha.</td></tr>';
            }
          ?>
        </tbody>
      </table>
    </div>
  </main>
  <script src="../scripts/toolBarExpanded.js"></script>

<script>
document.addEventListener('DOMContentLoaded', () => {
    const tableBody = document.querySelector('tbody');

    tableBody.addEventListener('dblclick', function(event) {
        const cell = event.target.closest('td');
        if (!cell) return; // Sai se não for uma célula <td>

        // Evita que a edição comece se já houver um input na célula
        if (cell.querySelector('input')) {
            return;
        }

        const originalValue = cell.textContent;
        const rowIndex = cell.parentElement.rowIndex - 1; // -1 para ajustar pelo thead
        const colIndex = cell.cellIndex;

        cell.innerHTML = `<input type="text" value="${originalValue}" class="edit-input" />`;
        const input = cell.querySelector('input');
        input.focus();

        // Evento para salvar ao sair do campo (perder o foco)
        input.addEventListener('blur', function() {
            const newValue = this.value;
            cell.innerHTML = newValue; // Atualiza visualmente a célula
            saveCellData(rowIndex, colIndex, newValue);
        });

        // Evento para salvar com "Enter" ou cancelar com "Escape"
        input.addEventListener('keydown', function(e) {
            if (e.key === 'Enter') {
                this.blur(); // Aciona o evento 'blur' para salvar
            } else if (e.key === 'Escape') {
                cell.innerHTML = originalValue; // Restaura o valor original
            }
        });
    });
});

function saveCellData(row, col, value) {
    const formData = new FormData();
    formData.append('row', row);
    formData.append('col', col);
    formData.append('value', value);

    fetch('../utils/salvar_celula.php', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            console.log(data.message); // Sucesso!
            // Poderia adicionar um feedback visual de sucesso aqui (ex: a célula pisca verde)
        } else {
            console.error(data.message);
            // Poderia adicionar um feedback visual de erro aqui (ex: a célula pisca vermelho)
            alert('Erro ao salvar: ' + data.message);
        }
    })
    .catch(error => {
        console.error('Erro de conexão:', error);
        alert('Erro de conexão ao tentar salvar.');
    });
}
</script>
</body>
</html>