    <div class="toolbar">
        <button class="toolbar-item" id="menu">
            <span class="text">Menu</span>
        </button>
        <button class="toolbar-item" id="reports">
            <span class="text">Relatórios</span>
        </button>
        <button class="toolbar-item" id="history">
            <span class="text">Históricos</span>
        </button>
        <div id="user-actions">
            <button class="toolbar-item" id="profile">
                <span class="text">Perfil</span>
            </button>
            <button class="toolbar-item" id="settings">
                <span class="text">Configurações</span>
            </button>
        </div>
    </div>