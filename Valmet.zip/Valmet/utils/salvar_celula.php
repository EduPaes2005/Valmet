<?php

// Passo 1: Incluir o autoloader do Composer e as classes necessárias
require '../vendor/autoload.php';

use PhpOffice\PhpSpreadsheet\IOFactory;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;
use PhpOffice\PhpSpreadsheet\Cell\Coordinate;

// Passo 2: Definir o caminho para o arquivo Excel
// ATENÇÃO: Deve ser o mesmo caminho usado no seu dashboard
$excelFilePath = '../utils/dados_producao.xlsx';

// Passo 3: Preparar a resposta que será enviada de volta ao JavaScript
// Por padrão, definimos como erro. Se tudo der certo, mudamos para sucesso.
header('Content-Type: application/json'); // Informa ao navegador que a resposta é JSON
$response = [
    'success' => false,
    'message' => 'Requisição inválida ou dados ausentes.'
];

// Passo 4: Verificar se a requisição é do tipo POST e se os dados esperados foram recebidos
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['row'], $_POST['col'], $_POST['value'])) {

    // Passo 5: Sanitizar e validar os dados recebidos do JavaScript
    // filter_var garante que a linha e a coluna são números inteiros.
    $row_index = filter_var($_POST['row'], FILTER_VALIDATE_INT);
    $col_index = filter_var($_POST['col'], FILTER_VALIDATE_INT);
    $value = $_POST['value']; // O valor pode ser texto, então não precisa ser um número.

    // Verifica se a sanitização funcionou. 'row' e 'col' devem ser 0 ou maiores.
    if ($row_index !== false && $col_index !== false) {

        // Bloco try...catch para tratar erros de manipulação do arquivo
        try {
            // Passo 6: Carregar a planilha existente
            $spreadsheet = IOFactory::load($excelFilePath);
            $sheet = $spreadsheet->getActiveSheet();

            // --- PONTO CRÍTICO: Conversão de Índices ---
            // O JavaScript nos envia índices baseados em 0 (a primeira linha é 0).
            // A biblioteca PhpSpreadsheet trabalha com índices baseados em 1 (a primeira linha é 1).
            // Além disso, nossa tabela no Excel tem um cabeçalho na linha 1.
            // Portanto, a linha de dados 0 do JavaScript corresponde à linha 2 no Excel.
            $excel_row = $row_index + 3;
            $excel_col = $col_index + 1;

            $cellCoordinate = Coordinate::stringFromColumnIndex($excel_col) . $excel_row;
            $sheet->setCellValue($cellCoordinate, $value);

            // Passo 8: Salvar o arquivo com as alterações
            $writer = new Xlsx($spreadsheet);
            $writer->save($excelFilePath);

            // Se chegou até aqui, a operação foi um sucesso
            $response['success'] = true;
            $response['message'] = 'Célula (' . $excel_row . ',' . $excel_col . ') atualizada com sucesso!';

        } catch (Exception $e) {
            // Se ocorrer um erro ao carregar, modificar ou salvar o arquivo
            $response['message'] = 'Erro ao manipular a planilha: ' . $e->getMessage();
        }
    } else {
        $response['message'] = 'Índice de linha ou coluna inválido.';
    }
}

// Passo 9: Enviar a resposta final em formato JSON para o JavaScript
echo json_encode($response);

?>